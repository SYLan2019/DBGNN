For the PeMS-Bay h5 file, please visit https://github.com/liyaguang/DCRNN
